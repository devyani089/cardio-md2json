import json
import os
import re
from pymongo import MongoClient
from bson import ObjectId
from dotenv import load_dotenv

load_dotenv()

def fetch_all_job_ids(mongo_uri):
    client = MongoClient(mongo_uri)
    db = client["parsing-data"]
    collection = db["data_1"]
    
    # Get distinct job_ids
    return collection.distinct("job_id")

def fetch_markdown_for_job_id(job_id, collection):
    documents = collection.find({"job_id": job_id})
    
    content_list = []
    for document in documents:
        content = document.get("content")
        if content:
            content_list.append(content)
    
    return content_list if content_list else None


# def extract_recommendations(md_content):
    
#     """
#     Extract recommendations from Markdown table content.
#     """
#     # Regex to match COR, LOE, and recommendation content
#     pattern = r"\|\s*([\d\w]+)\s*\|\s*([\w-]+)\s*\|\s*(.*?)\s*\|"
#     matches = re.findall(pattern, md_content)

#     recommendations = []
#     for cor, loe, recommendation in matches:
#         recommendations.append({
#             "recommendation_content": recommendation.strip(),
#             "recommendation_class": cor.strip(),
#             "rating": loe.strip()
#         })
    
#     return recommendations

def extract_recommendations(md_contents):
    """
    Extract recommendations from Markdown table content.
    """
    # Regex to match COR, LOE, and recommendation content
    pattern = r"\|\s*([\d\w]+)\s*\|\s*([\w-]+)\s*\|\s*(.*?)\s*\|"
    
    recommendations = []
    for md_content in md_contents:
        matches = re.findall(pattern, md_content)
        
        for cor, loe, recommendation in matches:
            recommendations.append({
                "recommendation_content": recommendation.strip(),
                "recommendation_class": cor.strip(),
                "rating": loe.strip()
            })
    
    return recommendations

def generate_json_chunks(recommendations):
    base_json = {
        "title": "Automated Extraction",
        "subCategory": [],
        "guide_title": "Automated Guide",
        "stage": ["Undefined"],
        "disease": ["Undefined"],
        "rationales": [],
        "references": [],
        "specialty": ["Undefined"]
    }

    json_chunks = []
    for rec in recommendations:
        chunk = base_json.copy()
        chunk.update({
            "recommendation_content": rec["recommendation_content"],
            "recommendation_class": rec["recommendation_class"],
            "rating": rec["rating"]
        })
        json_chunks.append(chunk)

    return json_chunks

def main():
    mongo_uri = os.getenv("MONGODB_URI")
    if not mongo_uri:
        print("MongoDB URI not found. Please ensure it's set in the .env file.")
        return

    client = MongoClient(mongo_uri)
    db = client["parsing-data"]
    collection = db["data_1"]

    # Fetch all distinct job_ids
    job_ids = fetch_all_job_ids(mongo_uri)
    
    print(f"Found {len(job_ids)} distinct job IDs.")
    
    for job_id in job_ids:
        # Fetch markdown contents for this job_id
        md_contents = fetch_markdown_for_job_id(job_id, collection)
        
        if md_contents:
            # Extract recommendations
            all_recommendations = extract_recommendations(md_contents)
            
            if all_recommendations:
                # Generate JSON chunks
                json_chunks = generate_json_chunks(all_recommendations)
                
                # Convert ObjectId to string for filename
                output_file = f"{str(job_id)}.json"
                
                # Save to JSON file
                with open(output_file, "w") as f:
                    json.dump(json_chunks, f, indent=2)
                
                print(f"JSON file generated: {output_file}")
            else:
                print(f"No recommendations found for Job ID: {job_id}")
        else:
            print(f"No content found for Job ID: {job_id}")

if __name__ == "__main__":
    main()