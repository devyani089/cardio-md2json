import json
import os
import re
from pymongo import MongoClient
from bson import ObjectId
from dotenv import load_dotenv

load_dotenv()

def fetch_job_content(mongo_uri, job_id):
    """
    Fetch job content from MongoDB using specified job_id
    
    Args:
        mongo_uri (str): MongoDB connection string
        job_id (str): Specific job ID to fetch
    
    Returns:
        list: Contents of documents matching the job_id
    """
    try:
        client = MongoClient(mongo_uri)
        db = client["parsing-data"]
        collection = db["data_1"]
        
        # Convert job_id to ObjectId
        object_job_id = ObjectId(job_id)
        
        # Find documents with matching job_id
        documents = collection.find({"job_id": object_job_id})
        
        # Extract content from documents
        content_list = [doc.get("content") for doc in documents if doc.get("content")]
        
        return content_list if content_list else None
    
    except Exception as e:
        print(f"Error fetching job content: {e}")
        return None

def extract_recommendations(md_contents):
    """
    Extract recommendations from Markdown table content.
    
    Args:
        md_contents (list): List of markdown contents
    
    Returns:
        list: Extracted recommendations
    """
    pattern = r"\|\s*([\d\w]+)\s*\|\s*([\w-]+)\s*\|\s*(.*?)\s*\|"
    
    recommendations = []
    for md_content in md_contents:
        matches = re.findall(pattern, md_content)
        
        for cor, loe, recommendation in matches:
            recommendations.append({
                "recommendation_content": recommendation.strip(),
                "recommendation_class": cor.strip(),
                "rating": loe.strip()
            })
    
    return recommendations

def generate_json_chunks(recommendations):
    """
    Generate JSON chunks from recommendations
    
    Args:
        recommendations (list): List of recommendation dictionaries
    
    Returns:
        list: JSON chunks with base template
    """
    base_json = {
        "title": "Automated Extraction",
        "subCategory": [],
        "guide_title": "Automated Guide",
        "stage": ["Undefined"],
        "disease": ["Undefined"],
        "rationales": [],
        "references": [],
        "specialty": ["Undefined"]
    }

    json_chunks = []
    for rec in recommendations:
        chunk = base_json.copy()
        chunk.update({
            "recommendation_content": rec["recommendation_content"],
            "recommendation_class": rec["recommendation_class"],
            "rating": rec["rating"]
        })
        json_chunks.append(chunk)

    return json_chunks

def main():
    # Manually input job_ids (multiple job_ids can be added)
    job_ids = input("Enter Job ID(s) separated by comma: ").split(',')
    job_ids = [job_id.strip() for job_id in job_ids]

    mongo_uri = os.getenv("MONGODB_URI")
    if not mongo_uri:
        print("MongoDB URI not found. Please ensure it's set in the .env file.")
        return

    all_json_chunks = []
    for job_id in job_ids:
        # Fetch markdown contents for job_id
        md_contents = fetch_job_content(mongo_uri, job_id)
        
        if md_contents:
            # Extract recommendations
            recommendations = extract_recommendations(md_contents)
            
            if recommendations:
                # Generate JSON chunks
                json_chunks = generate_json_chunks(recommendations)
                all_json_chunks.extend(json_chunks)
                
                print(f"Processed Job ID: {job_id}")
            else:
                print(f"No recommendations found for Job ID: {job_id}")
        else:
            print(f"No content found for Job ID: {job_id}")

    if all_json_chunks:
        # Save to a single JSON file
        output_file = f"{job_id}.json"
        with open(output_file, "w") as f:
            json.dump(all_json_chunks, f, indent=2)
        
        print(f"JSON file generated: {output_file}")
    else:
        print("No recommendations found for any job ID.")

if __name__ == "__main__":
    main()