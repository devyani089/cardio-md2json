# compass-connect-on-terminal
Run this code on terminal to extract markdown text in json format
